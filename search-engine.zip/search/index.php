<html>
       <head>
             <title>search engine </title>
       </head>
       <body>
             <form action = 'search.php' method = 'GET' >
                    <center>
                           <h1 >Search Engine </h1 >
                           <input type = 'text' size='90' name = 'search' >
                           </br >
                           </br >
                           <input type = 'submit' name = 'submit' value = 'Search source code' >
                           <option > 10 </ option >
                           <option > 20 </ option >
                           <option > 50 </ option >
                    </center >
             </form >
       </body >
</html > 

